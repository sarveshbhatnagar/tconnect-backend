"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const assert_1 = require("@aws-cdk/assert");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const tconnect_backend_stack_1 = require("../../lib/stacks/tconnect-backend-stack");
describe('LambdaStack', () => {
    let app;
    let stack;
    beforeAll(() => {
        app = new aws_cdk_lib_1.App();
        stack = new tconnect_backend_stack_1.LambdaStack(app, 'MyTestStack');
    });
    it('creates a Lambda function', () => {
        (0, assert_1.expect)(stack).to((0, assert_1.haveResource)('AWS::Lambda::Function'));
    });
    it('sets the correct runtime for the Lambda function', () => {
        (0, assert_1.expect)(stack).to((0, assert_1.haveResource)('AWS::Lambda::Function', {
            Runtime: 'nodejs14.x',
        }));
    });
    it('sets the correct handler for the Lambda function', () => {
        (0, assert_1.expect)(stack).to((0, assert_1.haveResource)('AWS::Lambda::Function', {
            Handler: 'index.handler',
        }));
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGNvbm5lY3QtYmFja2VuZC1zdGFjay50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vdGVzdC9zdGFja3MvdGNvbm5lY3QtYmFja2VuZC1zdGFjay50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsNENBQW9FO0FBQ3BFLDZDQUFrQztBQUNsQyxvRkFBc0U7QUFFdEUsUUFBUSxDQUFDLGFBQWEsRUFBRSxHQUFHLEVBQUU7SUFDM0IsSUFBSSxHQUFRLENBQUM7SUFDYixJQUFJLEtBQWtCLENBQUM7SUFFdkIsU0FBUyxDQUFDLEdBQUcsRUFBRTtRQUNiLEdBQUcsR0FBRyxJQUFJLGlCQUFHLEVBQUUsQ0FBQztRQUNoQixLQUFLLEdBQUcsSUFBSSxvQ0FBVyxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUM5QyxDQUFDLENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQywyQkFBMkIsRUFBRSxHQUFHLEVBQUU7UUFDbkMsSUFBQSxlQUFTLEVBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUEscUJBQVksRUFBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7SUFDN0QsQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsa0RBQWtELEVBQUUsR0FBRyxFQUFFO1FBQzFELElBQUEsZUFBUyxFQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FDakIsSUFBQSxxQkFBWSxFQUFDLHVCQUF1QixFQUFFO1lBQ3BDLE9BQU8sRUFBRSxZQUFZO1NBQ3RCLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsa0RBQWtELEVBQUUsR0FBRyxFQUFFO1FBQzFELElBQUEsZUFBUyxFQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FDakIsSUFBQSxxQkFBWSxFQUFDLHVCQUF1QixFQUFFO1lBQ3BDLE9BQU8sRUFBRSxlQUFlO1NBQ3pCLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7QUFFTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV4cGVjdCBhcyBleHBlY3RDREssIGhhdmVSZXNvdXJjZSB9IGZyb20gJ0Bhd3MtY2RrL2Fzc2VydCc7XG5pbXBvcnQgeyBBcHAgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgeyBMYW1iZGFTdGFjayB9IGZyb20gJy4uLy4uL2xpYi9zdGFja3MvdGNvbm5lY3QtYmFja2VuZC1zdGFjayc7XG5cbmRlc2NyaWJlKCdMYW1iZGFTdGFjaycsICgpID0+IHtcbiAgbGV0IGFwcDogQXBwO1xuICBsZXQgc3RhY2s6IExhbWJkYVN0YWNrO1xuXG4gIGJlZm9yZUFsbCgoKSA9PiB7XG4gICAgYXBwID0gbmV3IEFwcCgpO1xuICAgIHN0YWNrID0gbmV3IExhbWJkYVN0YWNrKGFwcCwgJ015VGVzdFN0YWNrJyk7XG4gIH0pO1xuXG4gIGl0KCdjcmVhdGVzIGEgTGFtYmRhIGZ1bmN0aW9uJywgKCkgPT4ge1xuICAgIGV4cGVjdENESyhzdGFjaykudG8oaGF2ZVJlc291cmNlKCdBV1M6OkxhbWJkYTo6RnVuY3Rpb24nKSk7XG4gIH0pO1xuXG4gIGl0KCdzZXRzIHRoZSBjb3JyZWN0IHJ1bnRpbWUgZm9yIHRoZSBMYW1iZGEgZnVuY3Rpb24nLCAoKSA9PiB7XG4gICAgZXhwZWN0Q0RLKHN0YWNrKS50byhcbiAgICAgIGhhdmVSZXNvdXJjZSgnQVdTOjpMYW1iZGE6OkZ1bmN0aW9uJywge1xuICAgICAgICBSdW50aW1lOiAnbm9kZWpzMTQueCcsXG4gICAgICB9KSxcbiAgICApO1xuICB9KTtcblxuICBpdCgnc2V0cyB0aGUgY29ycmVjdCBoYW5kbGVyIGZvciB0aGUgTGFtYmRhIGZ1bmN0aW9uJywgKCkgPT4ge1xuICAgIGV4cGVjdENESyhzdGFjaykudG8oXG4gICAgICBoYXZlUmVzb3VyY2UoJ0FXUzo6TGFtYmRhOjpGdW5jdGlvbicsIHtcbiAgICAgICAgSGFuZGxlcjogJ2luZGV4LmhhbmRsZXInLFxuICAgICAgfSksXG4gICAgKTtcbiAgfSk7XG5cbn0pO1xuIl19