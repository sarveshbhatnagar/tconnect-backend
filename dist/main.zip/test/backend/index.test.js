"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const backend_1 = require("../../lib/backend");
const utils_1 = require("../../lib/backend/utils/utils");
describe('Handler Invocation Test', () => {
    it('should invoke the handler', async () => {
        const result = await (0, backend_1.handler)({ "Event": "Test" });
        expect(result).toStrictEqual((0, utils_1.buildResponse)(200, { message: 'Hello World' }));
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXgudGVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Rlc3QvYmFja2VuZC9pbmRleC50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsK0NBQTRDO0FBQzVDLHlEQUE4RDtBQUU5RCxRQUFRLENBQUMseUJBQXlCLEVBQUUsR0FBRyxFQUFFO0lBQ3ZDLEVBQUUsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLElBQUksRUFBRTtRQUN6QyxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUEsaUJBQU8sRUFBQyxFQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO1FBQ2hELE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBQSxxQkFBYSxFQUFDLEdBQUcsRUFBRSxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDOUUsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGhhbmRsZXIgfSBmcm9tIFwiLi4vLi4vbGliL2JhY2tlbmRcIjtcbmltcG9ydCB7IGJ1aWxkUmVzcG9uc2UgfSBmcm9tIFwiLi4vLi4vbGliL2JhY2tlbmQvdXRpbHMvdXRpbHNcIjtcblxuZGVzY3JpYmUoJ0hhbmRsZXIgSW52b2NhdGlvbiBUZXN0JywgKCkgPT4ge1xuICBpdCgnc2hvdWxkIGludm9rZSB0aGUgaGFuZGxlcicsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBoYW5kbGVyKHtcIkV2ZW50XCI6IFwiVGVzdFwifSk7XG4gICAgZXhwZWN0KHJlc3VsdCkudG9TdHJpY3RFcXVhbChidWlsZFJlc3BvbnNlKDIwMCwgeyBtZXNzYWdlOiAnSGVsbG8gV29ybGQnfSkpO1xuICB9KTtcbn0pOyJdfQ==