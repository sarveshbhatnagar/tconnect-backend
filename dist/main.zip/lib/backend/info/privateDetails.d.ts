declare class PrivateDetails {
    private password;
    constructor(password: string);
    verifyPassword(inputPassword: string): boolean;
}
declare class PrivateDetailsBuilder {
    password: string;
    constructor();
    withPassword(password: string): this;
    build(): PrivateDetails;
    static from(obj: {
        password?: string;
    }): PrivateDetails;
}
export { PrivateDetails, PrivateDetailsBuilder };
