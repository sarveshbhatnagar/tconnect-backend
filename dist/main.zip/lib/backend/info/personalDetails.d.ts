declare class PersonalDetails {
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    username: string;
    constructor(username: string, firstName?: string, lastName?: string | undefined, email?: string | undefined, phone?: string);
}
declare class PersonalDetailsBuilder {
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    username: string;
    constructor(username: string);
    withEmail(email?: string): this;
    withFirstName(firstName?: string): this;
    withLastName(lastName?: string): this;
    withPhone(phone?: string): this;
    build(): PersonalDetails;
    static from(obj: {
        firstName?: string;
        lastName?: string;
        email?: string;
        phone?: string;
        username: string;
    }): PersonalDetails;
}
export { PersonalDetails, PersonalDetailsBuilder };
