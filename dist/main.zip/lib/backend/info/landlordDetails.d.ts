declare class LandlordDetils {
    tenants: string[];
    photo: string;
    numberOfTenants: number;
    constructor(tenants: string[], photo: string, numberOfTenants: number);
}
declare class LandlordDetilsBuilder {
    tenants: string[];
    photo: string;
    numberOfTenants: number;
    constructor();
    withTenants(tenants: string[]): this;
    withPhoto(photo: string): this;
    withNumberOfTenants(numberOfTenants: number): this;
    build(): LandlordDetils;
    static from(obj: {
        tenants?: string[];
        photo?: string;
        numberOfTenants?: number;
    }): LandlordDetils;
}
export { LandlordDetils, LandlordDetilsBuilder };
