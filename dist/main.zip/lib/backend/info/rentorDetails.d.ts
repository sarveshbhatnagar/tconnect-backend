declare class RentorDetials {
    leaseDate: string;
    monthlyCost: number;
    dueDate: string;
    missedPayments: number;
    rentedSince: string;
    rentedTill: string;
    rentorScore: number;
    constructor(leaseDate: string, monthlyCost: number, dueDate: string, missedPayments: number, rentedSince: string, rentedTill: string, rentorScore: number);
}
declare class RentorDetialsBuilder {
    leaseDate: string;
    monthlyCost: number;
    dueDate: string;
    missedPayments: number;
    rentedSince: string;
    rentedTill: string;
    rentorScore: number;
    constructor();
    withLeaseDate(leaseDate: string): this;
    withMonthlyCost(monthlyCost: number): this;
    withDueDate(dueDate: string): this;
    withMissedPayments(missedPayments: number): this;
    withRentedSince(rentedSince: string): this;
    withRentedTill(rentedTill: string): this;
    withRentorScore(rentorScore: number): this;
    build(): RentorDetials;
    static from(obj: {
        leaseDate: string;
        monthlyCost: number;
        dueDate: string;
        missedPayments: number;
        rentedSince: string;
        rentedTill: string;
        rentorScore?: number;
    }): RentorDetials;
}
export { RentorDetials, RentorDetialsBuilder };
