declare const validateStatusCode: (statusCode: number) => boolean;
declare const validateResponse: (statusCode: number, body: any) => boolean;
declare function buildResponse(statusCode: number, body: any): {
    isBase64Encoded: boolean;
    statusCode: number;
    headers: {
        'Access-Control-Allow-Origin': string;
        'Content-Type': string;
    };
    body: string;
};
export { buildResponse, validateStatusCode, validateResponse };
